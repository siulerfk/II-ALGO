
#ifndef CONSTANTES_H_
#define CONSTANTES_H_


#define VIDAS 7


#endif /* CONSTANTES_H_ */
