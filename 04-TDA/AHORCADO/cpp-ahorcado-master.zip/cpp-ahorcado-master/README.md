Algoritmos y Programación 2 - FI UBA

# Ejemplo de aplicación C++

## Descripción

Juego del ahorcado, construido como un ejemplo de aplicación desarrollada en C++.

![Ahorcado](img/juego.gif)

## Fuentes

 * [`principal.cpp`](../master/src/principal.cpp)
 * [`interacciones.h`](../master/src/interacciones.h)
 * [`interacciones.cpp`](../master/src/interacciones.cpp)
 * [`reglas.h`](../master/src/reglas.h)
 * [`reglas.cpp`](../master/src/reglas.cpp)
 * [`constantes.cpp`](../master/src/constantes.cpp)